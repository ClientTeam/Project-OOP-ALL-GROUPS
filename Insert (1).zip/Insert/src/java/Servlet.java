/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Narith
 * comments added by Katie
 */
public class Servlet extends HttpServlet {
 Connection con=null;
   String name=null;
   String message="";
   public void init(ServletConfig config) throws ServletException{
       try{ //this establishes the connection to the localhost server
           Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
          con = DriverManager.getConnection("jdbc:derby://localhost:1527/schoolDB", "katie", "katie");
         message="Connect successful";
       }
       catch(Exception e){ // error given if unable to make connection
          message="Connection fail";
          return;
       }
   }
    public void doGet(HttpServletRequest request,HttpServletResponse response) 
           throws ServletException, IOException{
       
        //load strings from user input on the index page
       String instructor=request.getParameter("instructor");
       String name=request.getParameter("name");
       String room=request.getParameter("room");
       String time=request.getParameter("time");
       String end=request.getParameter("end");
       String course_code=request.getParameter("code");
       String class_type=request.getParameter("class_type");
       
       // if successful, use sql to insert values into the database
       try{
           Statement st= con.createStatement();
           //removing next line bc we don't do database - it will be replaced by logic team code
           int data = st.executeUpdate("INSERT INTO tbl_exam VALUES ('"+instructor+"','"+name+"','"+room+"','"+time+"','"+end+"','"+course_code+"','"+class_type+"')");
           //add logic team's instructor class function --- to schedule exam (add or schedule exam method)
           st.close();
       }
       catch(SQLException e){ // error prints if not able to input
           e.printStackTrace();
       }
       try{
           
           // logic team responce method (return exam id when successful) for client
           // it is generated for us and then we will show their confirmation info like below
           
           
           
           // this is the confirmation feedback showing what was inserted into the db
                   PrintWriter out = response.getWriter();
           response.setContentType("text/html");
           out.println("<html><head><title>Order Confirmation</title></head><body>");
           out.println("Successful");
           out.println("<br/>");
           out.println("Course Name: "+name);
           out.println("<br/>");
           out.println("Course Code:"+ course_code);
           out.println("<br/>");
           out.println("Room Number: "+room);
           out.println("<br/>");
           out.println("Start Time: "+time);
           out.println("<br/>");
           out.println("End Time: "+end);
           out.println("<br/>");
           out.println("Class or Lab <br/>"+class_type);
           
         
           out.println("</body></html>");
           out.close();
           
       } // error prints if unable to print the confirmation
       catch(Exception ei){
           ei.printStackTrace();
       }
   }

}
